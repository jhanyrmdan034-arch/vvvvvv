<?php
require_once __DIR__ . '/inc/config.php';
require_once __DIR__ . '/inc/icons.php';
require_once dirname(__DIR__) . '/ui_config_helper.php';
require_auth();

setcookie('XSRF-TOKEN', csrf_token(), [
    'path' => '/',
    'secure' => !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off',
    'samesite' => 'Strict',
]);

$defaultKeyboardJson = '{"keyboard":[[{"text":"text_sell","style":"success"},{"text":"text_extend","style":"primary"}],[{"text":"text_usertest","style":"primary"},{"text":"text_wheel_luck"}],[{"text":"text_Purchased_services"},{"text":"accountwallet","style":"success"}],[{"text":"text_affiliates"},{"text":"text_Tariff_list"}],[{"text":"text_support"},{"text":"text_help"}],[{"text":"text_agentpanel"},{"text":"text_requestagent"}]]}';

$method = $_SERVER['REQUEST_METHOD'];
$rawInput = file_get_contents('php://input');
$jsonInput = json_decode($rawInput, true);

if ($method === 'POST' && !csrf_check_value($_SERVER['HTTP_X_XSRF_TOKEN'] ?? ($_POST['_csrf'] ?? ''))) {
    http_response_code(403);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['ok' => false, 'error' => 'CSRF invalid']);
    exit;
}

if ($method === 'POST' && is_array($jsonInput)) {
    header('Content-Type: application/json; charset=utf-8');
    if (isset($jsonInput['ui_config']) && is_array($jsonInput['ui_config'])) {
        $ok = mirza_ui_save_config($jsonInput['ui_config']);
        echo json_encode(['ok' => $ok]);
        exit;
    }

    $keyboard = $jsonInput['keyboard'] ?? $jsonInput;
    $validKeyboard = is_array($keyboard) && count($keyboard) > 0;
    if ($validKeyboard) {
        foreach ($keyboard as $row) {
            if (!is_array($row) || count($row) === 0) {
                $validKeyboard = false;
                break;
            }
            foreach ($row as $button) {
                if (!is_array($button) || !isset($button['text']) || !is_string($button['text']) || trim($button['text']) === '') {
                    $validKeyboard = false;
                    break 2;
                }
            }
        }
    }
    if (!$validKeyboard) {
        http_response_code(422);
        echo json_encode(['ok' => false, 'error' => 'Invalid keyboard structure']);
        exit;
    }
    $keyboardmain = ['keyboard' => $keyboard];
    update('setting', 'keyboardmain', json_encode($keyboardmain, JSON_UNESCAPED_UNICODE), null, null);
    echo json_encode(['ok' => true]);
    exit;
}

$action = filter_input(INPUT_GET, 'action');
if ($action === 'kbcolor') {
    csrf_check_get();
    $kbColor = (string) filter_input(INPUT_GET, 'color');
    $kbAllowedColors = ['primary', 'success', 'danger', 'default'];
    if (in_array($kbColor, $kbAllowedColors, true)) {
        $kbSetting = select('setting', 'keyboardmain', null, null, 'select');
        $kbLayout = json_decode($kbSetting['keyboardmain'] ?? '', true);
        if (is_array($kbLayout) && isset($kbLayout['keyboard']) && is_array($kbLayout['keyboard'])) {
            foreach ($kbLayout['keyboard'] as $kbRowIndex => $kbRow) {
                if (!is_array($kbRow)) {
                    continue;
                }
                foreach ($kbRow as $kbBtnIndex => $kbBtn) {
                    if (!is_array($kbBtn)) {
                        continue;
                    }
                    if ($kbColor === 'default') {
                        unset($kbLayout['keyboard'][$kbRowIndex][$kbBtnIndex]['style']);
                    } else {
                        $kbLayout['keyboard'][$kbRowIndex][$kbBtnIndex]['style'] = $kbColor;
                    }
                }
            }
            update('setting', 'keyboardmain', json_encode($kbLayout, JSON_UNESCAPED_UNICODE), null, null);
        }
    }
    header('Location: keyboard.php');
    exit;
}

if ($action === 'reaset') {
    csrf_check_get();
    update('setting', 'keyboardmain', $defaultKeyboardJson, null, null);
    mirza_ui_save_config(mirza_ui_default_config());
    header('Location: keyboard.php');
    exit;
}

$settingRow = select('setting', '*', null, null, 'select');
$currentLayout = json_decode($settingRow['keyboardmain'] ?? $defaultKeyboardJson, true);
if (!is_array($currentLayout) || empty($currentLayout['keyboard'])) {
    $currentLayout = json_decode($defaultKeyboardJson, true);
}
$uiConfig = mirza_ui_get_config();
$isInlineMode = ($settingRow['inlinebtnmain'] ?? 'offinline') === 'oninline';

$actionCatalog = [
    ['key' => 'text_sell', 'defaultLabel' => $textbotlang['textbot']['sell'] ?? '🛒 خرید سرویس', 'desc' => 'شروع فرآیند خرید سرویس جدید'],
    ['key' => 'text_extend', 'defaultLabel' => $textbotlang['textbot']['extend'] ?? '♻️ تمدید سرویس', 'desc' => 'تمدید سرویس‌های فعلی کاربر'],
    ['key' => 'text_Purchased_services', 'defaultLabel' => $textbotlang['textbot']['purchasedServices'] ?? '📦 سرویس‌های من', 'desc' => 'مشاهده و مدیریت سرویس‌های خریداری‌شده'],
    ['key' => 'accountwallet', 'defaultLabel' => $textbotlang['textbot']['accountWallet'] ?? '🏦 کیف پول + شارژ', 'desc' => 'موجودی حساب و افزایش اعتبار'],
    ['key' => 'text_usertest', 'defaultLabel' => $textbotlang['textbot']['userTest'] ?? '🧪 اکانت تست', 'desc' => 'دریافت اکانت تست رایگان'],
    ['key' => 'text_Tariff_list', 'defaultLabel' => $textbotlang['textbot']['tariffList'] ?? '💎 تعرفه‌ها و قیمت‌ها', 'desc' => 'نمایش لیست قیمت و پلن‌ها'],
    ['key' => 'text_affiliates', 'defaultLabel' => $textbotlang['textbot']['affiliates'] ?? '👥 زیرمجموعه‌گیری', 'desc' => 'لینک دعوت و پورسانت'],
    ['key' => 'text_wheel_luck', 'defaultLabel' => $textbotlang['textbot']['wheelLuck'] ?? '🎡 گردونه شانس', 'desc' => 'گردونه شانس و جوایز'],
    ['key' => 'text_support', 'defaultLabel' => $textbotlang['textbot']['support'] ?? '💬 پشتیبانی', 'desc' => 'ارسال پیام به پشتیبانی'],
    ['key' => 'text_help', 'defaultLabel' => $textbotlang['textbot']['help'] ?? '📚 راهنمای اتصال', 'desc' => 'آموزش اتصال در سیستم‌عامل‌ها'],
    ['key' => 'text_agentpanel', 'defaultLabel' => $textbotlang['textbot']['agentPanel'] ?? '👨‍💻 پنل نمایندگی', 'desc' => 'پنل اختصاصی نمایندگان'],
    ['key' => 'text_requestagent', 'defaultLabel' => $textbotlang['textbot']['requestAgent'] ?? '🤝 درخواست نمایندگی', 'desc' => 'ثبت درخواست همکاری و نمایندگی'],
];

$pageTitle = 'مدیریت ظاهر و دکمه‌های ربات';
$pageLede = 'چیدمان دکمه‌ها، رنگ‌بندی، تم‌های آماده، تنظیمات صفحه محصولات و پیش‌نمایش زنده تلگرام';
$activeNav = 'keyboard';
include __DIR__ . '/inc/layout_head.php';
?>

<style>
.uim-grid { display: grid; grid-template-columns: 1.25fr 0.95fr; gap: 18px; align-items: start; }
@media (max-width: 1024px) { .uim-grid { grid-template-columns: 1fr; } }
.uim-card { background: var(--sf); border: 1px solid var(--bd); border-radius: 14px; padding: 16px; }
.uim-tabs { display: flex; gap: 8px; flex-wrap: wrap; margin-bottom: 14px; }
.uim-tab { padding: 8px 14px; border-radius: 10px; border: 1px solid var(--bd); background: transparent; color: var(--mute); cursor: pointer; font-weight: 600; font-size: .85rem; }
.uim-tab.active { background: var(--acs); color: var(--ach); border-color: var(--ach); }
.uim-themes { display: grid; grid-template-columns: repeat(3, minmax(0, 1fr)); gap: 8px; margin-bottom: 14px; }
@media (max-width: 640px) { .uim-themes { grid-template-columns: repeat(2, minmax(0, 1fr)); } }
.uim-theme-btn { padding: 9px 10px; border-radius: 10px; border: 1px solid var(--bd); background: rgba(255,255,255,.03); color: var(--tx); cursor: pointer; font-size: .8rem; font-weight: 600; display: flex; align-items: center; justify-content: space-between; }
.uim-theme-btn.active { border-color: var(--ach); box-shadow: 0 0 0 1px var(--ach); }
.uim-row { background: rgba(255,255,255,.025); border: 1px dashed var(--bd); border-radius: 12px; padding: 10px; margin-bottom: 10px; }
.uim-row-head { display: flex; justify-content: space-between; align-items: center; margin-bottom: 8px; font-size: .78rem; color: var(--mute); }
.uim-row-btns { display: flex; flex-wrap: wrap; gap: 8px; min-height: 40px; }
.uim-btn-chip { flex: 1 1 140px; display: flex; align-items: center; justify-content: space-between; gap: 6px; padding: 8px 10px; border-radius: 10px; border: 1px solid rgba(255,255,255,.12); background: rgba(255,255,255,.05); color: #fff; cursor: grab; user-select: none; font-size: .84rem; }
.uim-btn-chip.style-primary { background: rgba(41,138,207,.28); border-color: rgba(41,138,207,.7); }
.uim-btn-chip.style-success { background: rgba(97,199,82,.25); border-color: rgba(97,199,82,.7); }
.uim-btn-chip.style-danger  { background: rgba(224,83,86,.26); border-color: rgba(224,83,86,.7); }
.uim-btn-chip.is-disabled { opacity: .45; }
.uim-chip-actions { display: flex; gap: 4px; }
.uim-icon-btn { border: none; background: rgba(255,255,255,.1); color: #fff; border-radius: 6px; padding: 3px 6px; cursor: pointer; font-size: .75rem; }
.uim-tg-phone { background: linear-gradient(160deg, #0b1220 0%, #111b2e 55%, #0b1628 100%); border: 1px solid rgba(255,255,255,.12); border-radius: 22px; padding: 14px; color: #e5e7eb; }
.uim-tg-bubble { background: rgba(255,255,255,.07); backdrop-filter: blur(10px); border: 1px solid rgba(255,255,255,.1); border-radius: 14px; padding: 12px 14px; font-size: .85rem; line-height: 1.7; margin-bottom: 10px; }
.uim-tg-kb { display: flex; flex-direction: column; gap: 6px; }
.uim-tg-row { display: grid; gap: 6px; }
.uim-tg-btn { padding: 10px 8px; border-radius: 10px; text-align: center; font-size: .82rem; font-weight: 600; background: rgba(255,255,255,.1); border: 1px solid rgba(255,255,255,.12); color: #fff; backdrop-filter: blur(8px); }
.uim-tg-btn.style-primary { background: linear-gradient(135deg, rgba(41,138,207,.85), rgba(30,100,170,.85)); border-color: rgba(110,190,255,.45); }
.uim-tg-btn.style-success { background: linear-gradient(135deg, rgba(67,160,71,.85), rgba(46,125,50,.85)); border-color: rgba(129,199,132,.45); }
.uim-tg-btn.style-danger  { background: linear-gradient(135deg, rgba(224,83,86,.85), rgba(183,28,28,.85)); border-color: rgba(255,138,128,.45); }
.uim-note { font-size: .78rem; color: var(--mute); background: rgba(255,255,255,.03); border: 1px solid var(--bd); border-radius: 10px; padding: 10px 12px; margin-top: 10px; line-height: 1.6; }
</style>

<div class="uim-tabs">
    <button type="button" class="uim-tab active" data-tab="main">🎛️ منوی اصلی ربات</button>
    <button type="button" class="uim-tab" data-tab="submenus">🛍️ صفحه محصولات، دسته‌بندی و زمان</button>
    <a href="bottext.php" class="uim-tab" style="text-decoration:none">📝 ویرایشگر متن‌های ربات</a>
</div>

<div id="tab-main" class="uim-grid">
    <div class="uim-card">
        <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:8px;margin-bottom:12px">
            <strong>تم‌های آماده</strong>
            <div style="display:flex;gap:6px;flex-wrap:wrap">
                <button type="button" class="btn btn-ghost btn-sm" id="btnAddRow">➕ ردیف جدید</button>
                <button type="button" class="btn btn-ghost btn-sm" id="btnAddButton">🔘 افزودن دکمه</button>
                <button type="button" class="btn btn-ghost btn-sm" id="btnRevert">↩️ لغو تغییرات</button>
                <a class="btn btn-ghost btn-sm" href="keyboard.php?action=reaset&_csrf=<?= urlencode(csrf_token()) ?>" onclick="return confirm('چیدمان و تنظیمات ظاهر به پیش‌فرض برگردد؟')">🔄 بازگردانی پیش‌فرض</a>
            </div>
        </div>

        <div class="uim-themes" id="themeGrid">
            <button type="button" class="uim-theme-btn" data-theme="blue_neon"><span>🔵 Blue Neon</span><span>●</span></button>
            <button type="button" class="uim-theme-btn" data-theme="purple_premium"><span>🟣 Purple Premium</span><span>●</span></button>
            <button type="button" class="uim-theme-btn" data-theme="emerald"><span>🟢 Emerald</span><span>●</span></button>
            <button type="button" class="uim-theme-btn" data-theme="dark_glass"><span>🌑 Dark Glass</span><span>●</span></button>
            <button type="button" class="uim-theme-btn" data-theme="gold_luxury"><span>🟡 Gold Luxury</span><span>●</span></button>
            <button type="button" class="uim-theme-btn" data-theme="midnight"><span>🌌 Midnight</span><span>●</span></button>
        </div>

        <div id="rowsContainer"></div>

        <div style="display:flex;justify-content:space-between;align-items:center;margin-top:14px;gap:10px;flex-wrap:wrap">
            <span id="saveStatus" style="font-size:.82rem;color:var(--mute)"></span>
            <button type="button" class="btn btn-primary" id="btnSaveMain">💾 ذخیره نهایی منوی اصلی</button>
        </div>

        <div class="uim-note">
            ℹ️ <strong>محدودیت رسمی تلگرام:</strong> API تلگرام برای دکمه‌های کیبورد فقط ۳ رنگ رسمی (آبی، سبز، قرمز) و حالت پیش‌فرض را پشتیبانی می‌کند و امکان شفافیت/گلس واقعی روی کلاینت تلگرام وجود ندارد. در پیش‌نمایش پنل ظاهر شیشه‌ای مدرن نمایش داده می‌شود و در تلگرام رنگ‌های رسمی متناظر اعمال می‌گردد.
        </div>
    </div>

    <div class="uim-card">
        <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:10px">
            <strong>👁️ پیش‌نمایش زنده تلگرام</strong>
            <span class="tag"><?= $isInlineMode ? 'حالت شیشه‌ای (Inline)' : 'حالت کیبورد معمولی' ?></span>
        </div>
        <div class="uim-tg-phone" id="tgPreviewWrap">
            <div class="uim-tg-bubble">
                ✨ <strong>به ربات فروش VPN خوش آمدید!</strong><br>
                لطفاً یکی از گزینه‌های زیر را انتخاب کنید:
            </div>
            <div class="uim-tg-kb" id="tgPreviewKb"></div>
        </div>
    </div>
</div>

<div id="tab-submenus" class="uim-grid" style="display:none">
    <div class="uim-card">
        <h3 style="margin-top:0;margin-bottom:12px;font-size:1rem">⚙️ تنظیمات چیدمان صفحه محصولات و منوهای خرید</h3>
        <div class="field" style="margin-bottom:12px">
            <label>تعداد ستون لیست محصولات</label>
            <select id="cfgProductCols" class="select">
                <option value="1" <?= (int)$uiConfig['product_columns'] === 1 ? 'selected' : '' ?>>۱ ستونه (تمام‌عرض — خواناتر برای نام و قیمت)</option>
                <option value="2" <?= (int)$uiConfig['product_columns'] === 2 ? 'selected' : '' ?>>۲ ستونه (فشرده)</option>
            </select>
        </div>
        <div class="field" style="margin-bottom:12px">
            <label>جداکننده نام محصول و قیمت</label>
            <input type="text" id="cfgPriceSep" class="input" value="<?= htmlspecialchars($uiConfig['product_price_separator']) ?>" maxlength="12">
        </div>
        <div class="field" style="margin-bottom:12px">
            <label style="display:flex;align-items:center;gap:8px;cursor:pointer">
                <input type="checkbox" id="cfgProductEmoji" <?= !empty($uiConfig['show_product_emoji']) ? 'checked' : '' ?>>
                نمایش ایموجی 💎 کنار نام محصولات
            </label>
        </div>
        <div class="field" style="margin-bottom:12px">
            <label>تعداد ستون منوی دسته‌بندی‌ها</label>
            <select id="cfgCategoryCols" class="select">
                <option value="1" <?= (int)$uiConfig['category_columns'] === 1 ? 'selected' : '' ?>>۱ ستونه</option>
                <option value="2" <?= (int)$uiConfig['category_columns'] === 2 ? 'selected' : '' ?>>۲ ستونه (پیشنهادی)</option>
            </select>
        </div>
        <div class="field" style="margin-bottom:14px">
            <label>تعداد ستون منوی مدت‌زمان سرویس</label>
            <select id="cfgDurationCols" class="select">
                <option value="1" <?= (int)$uiConfig['duration_columns'] === 1 ? 'selected' : '' ?>>۱ ستونه</option>
                <option value="2" <?= (int)$uiConfig['duration_columns'] === 2 ? 'selected' : '' ?>>۲ ستونه (پیشنهادی)</option>
            </select>
        </div>
        <div style="display:flex;justify-content:space-between;align-items:center">
            <span id="subSaveStatus" style="font-size:.82rem;color:var(--mute)"></span>
            <button type="button" class="btn btn-primary" id="btnSaveSub">💾 ذخیره تنظیمات صفحات</button>
        </div>
    </div>

    <div class="uim-card">
        <strong style="display:block;margin-bottom:10px">👁️ پیش‌نمایش صفحه انتخاب محصول</strong>
        <div class="uim-tg-phone">
            <div class="uim-tg-bubble">
                🛍️ <strong>لطفاً سرویس مورد نظر خود را انتخاب کنید:</strong>
            </div>
            <div class="uim-tg-kb" id="tgProductPreview"></div>
        </div>
    </div>
</div>

<!-- Edit Button Modal -->
<div id="editModal" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,.65);z-index:999;align-items:center;justify-content:center;padding:16px">
    <div class="uim-card" style="width:100%;max-width:420px">
        <h3 style="margin-top:0;font-size:1rem">✏️ ویرایش دکمه</h3>
        <div class="field" style="margin-bottom:10px">
            <label>عنوان دلخواه (خالی = عنوان پیش‌فرض زبان)</label>
            <input type="text" id="editBtnLabel" class="input" placeholder="مثلاً: 🛒 خرید اشتراک ویژه">
        </div>
        <div class="field" style="margin-bottom:10px">
            <label>رنگ دکمه</label>
            <select id="editBtnStyle" class="select">
                <option value="">پیش‌فرض (شیشه‌ای/سفید)</option>
                <option value="success">🟢 سبز (Success)</option>
                <option value="primary">🔵 آبی (Primary)</option>
                <option value="danger">🔴 قرمز (Danger)</option>
            </select>
        </div>
        <div class="field" style="margin-bottom:14px">
            <label style="display:flex;align-items:center;gap:8px;cursor:pointer">
                <input type="checkbox" id="editBtnDisabled">
                غیرفعال کردن موقت این دکمه
            </label>
        </div>
        <div style="display:flex;justify-content:flex-end;gap:8px">
            <button type="button" class="btn btn-ghost btn-sm" onclick="closeEditModal()">انصراف</button>
            <button type="button" class="btn btn-primary btn-sm" id="btnApplyEdit">تایید</button>
        </div>
    </div>
</div>

<!-- Add Button Modal -->
<div id="addModal" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,.65);z-index:999;align-items:center;justify-content:center;padding:16px">
    <div class="uim-card" style="width:100%;max-width:460px;max-height:85vh;overflow:auto">
        <h3 style="margin-top:0;font-size:1rem">➕ افزودن دکمه جدید</h3>
        <p style="font-size:.8rem;color:var(--mute);margin-top:0">فقط اکشن‌های واقعی و متصل به ربات قابل انتخاب هستند تا عملکرد دکمه‌ها بدون خطا بماند:</p>
        <div id="catalogList" style="display:flex;flex-direction:column;gap:8px"></div>
        <div style="display:flex;justify-content:flex-end;margin-top:12px">
            <button type="button" class="btn btn-ghost btn-sm" onclick="document.getElementById('addModal').style.display='none'">بستن</button>
        </div>
    </div>
</div>

<script>
const CSRF_TOKEN = <?= json_encode(csrf_token()) ?>;
const ACTION_CATALOG = <?= json_encode($actionCatalog, JSON_UNESCAPED_UNICODE) ?>;
const INITIAL_KEYBOARD = <?= json_encode($currentLayout['keyboard'], JSON_UNESCAPED_UNICODE) ?>;
let activeTheme = <?= json_encode($uiConfig['theme'] ?? 'dark_glass') ?>;

let rows = JSON.parse(JSON.stringify(INITIAL_KEYBOARD));
let dragSrc = null;
let editingPos = null;

function getDefaultLabel(key) {
    const found = ACTION_CATALOG.find(a => a.key === key);
    return found ? found.defaultLabel : key;
}

function renderEditor() {
    const container = document.getElementById('rowsContainer');
    container.innerHTML = '';
    rows.forEach((row, rIdx) => {
        const rowEl = document.createElement('div');
        rowEl.className = 'uim-row';
        rowEl.innerHTML = `
            <div class="uim-row-head">
                <span>ردیف ${rIdx + 1} (${row.length} دکمه)</span>
                <div style="display:flex;gap:4px">
                    <button type="button" class="uim-icon-btn" onclick="moveRow(${rIdx}, -1)">⬆️</button>
                    <button type="button" class="uim-icon-btn" onclick="moveRow(${rIdx}, 1)">⬇️</button>
                    <button type="button" class="uim-icon-btn" onclick="deleteRow(${rIdx})">🗑️</button>
                </div>
            </div>
            <div class="uim-row-btns" data-row="${rIdx}"></div>
        `;
        const btnsWrap = rowEl.querySelector('.uim-row-btns');
        btnsWrap.addEventListener('dragover', e => e.preventDefault());
        btnsWrap.addEventListener('drop', e => {
            e.preventDefault();
            if (!dragSrc) return;
            const [moved] = rows[dragSrc.r].splice(dragSrc.c, 1);
            rows[rIdx].push(moved);
            cleanupEmptyRows();
            dragSrc = null;
            renderAll();
        });

        row.forEach((btn, cIdx) => {
            const chip = document.createElement('div');
            const styleCls = btn.style ? 'style-' + btn.style : '';
            const disCls = btn.disabled ? 'is-disabled' : '';
            chip.className = `uim-btn-chip ${styleCls} ${disCls}`;
            chip.draggable = true;
            chip.addEventListener('dragstart', () => { dragSrc = { r: rIdx, c: cIdx }; });
            const title = (btn.custom_label && btn.custom_label.trim()) ? btn.custom_label : getDefaultLabel(btn.text);
            chip.innerHTML = `
                <span style="overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${escapeHtml(title)}</span>
                <span class="uim-chip-actions">
                    <button type="button" class="uim-icon-btn" onclick="openEditModal(${rIdx}, ${cIdx})">✏️</button>
                    <button type="button" class="uim-icon-btn" onclick="removeBtn(${rIdx}, ${cIdx})">✖</button>
                </span>
            `;
            btnsWrap.appendChild(chip);
        });
        container.appendChild(rowEl);
    });
}

function renderPreview() {
    const kb = document.getElementById('tgPreviewKb');
    kb.innerHTML = '';
    rows.forEach(row => {
        const visibleBtns = row.filter(b => !b.disabled);
        if (!visibleBtns.length) return;
        const rEl = document.createElement('div');
        rEl.className = 'uim-tg-row';
        rEl.style.gridTemplateColumns = `repeat(${visibleBtns.length}, minmax(0, 1fr))`;
        visibleBtns.forEach(btn => {
            const bEl = document.createElement('div');
            bEl.className = 'uim-tg-btn ' + (btn.style ? 'style-' + btn.style : '');
            const title = (btn.custom_label && btn.custom_label.trim()) ? btn.custom_label : getDefaultLabel(btn.text);
            bEl.textContent = title;
            rEl.appendChild(bEl);
        });
        kb.appendChild(rEl);
    });
}

function renderProductPreview() {
    const wrap = document.getElementById('tgProductPreview');
    if (!wrap) return;
    const cols = parseInt(document.getElementById('cfgProductCols').value, 10) || 1;
    const sep = document.getElementById('cfgPriceSep').value || ' 💳 ';
    const emoji = document.getElementById('cfgProductEmoji').checked ? '💎 ' : '';
    const sample = [
        { name: 'آلمان ۳۰ روزه ۵۰ گیگ', price: '۱۲۰,۰۰۰ تومان' },
        { name: 'هلند ۳۰ روزه ۱۰۰ گیگ', price: '۲۱۰,۰۰۰ تومان' },
        { name: 'فنلاند ۶۰ روزه نامحدود', price: '۳۹۰,۰۰۰ تومان' },
    ];
    wrap.innerHTML = '';
    for (let i = 0; i < sample.length; i += cols) {
        const chunk = sample.slice(i, i + cols);
        const rEl = document.createElement('div');
        rEl.className = 'uim-tg-row';
        rEl.style.gridTemplateColumns = `repeat(${chunk.length}, minmax(0, 1fr))`;
        chunk.forEach(item => {
            const bEl = document.createElement('div');
            bEl.className = 'uim-tg-btn';
            bEl.textContent = `${emoji}${item.name}${sep}${item.price}`;
            rEl.appendChild(bEl);
        });
        wrap.appendChild(rEl);
    }
    const backRow = document.createElement('div');
    backRow.className = 'uim-tg-row';
    backRow.innerHTML = '<div class="uim-tg-btn style-danger">🔙 بازگشت به منوی اصلی</div>';
    wrap.appendChild(backRow);
}

function renderAll() {
    renderEditor();
    renderPreview();
    document.querySelectorAll('.uim-theme-btn').forEach(b => {
        b.classList.toggle('active', b.dataset.theme === activeTheme);
    });
}

function cleanupEmptyRows() {
    rows = rows.filter(r => r.length > 0);
}
function moveRow(idx, dir) {
    const target = idx + dir;
    if (target < 0 || target >= rows.length) return;
    [rows[idx], rows[target]] = [rows[target], rows[idx]];
    renderAll();
}
function deleteRow(idx) {
    if (rows.length <= 1) return alert('حداقل یک ردیف باید باقی بماند.');
    rows.splice(idx, 1);
    renderAll();
}
function removeBtn(r, c) {
    rows[r].splice(c, 1);
    cleanupEmptyRows();
    renderAll();
}

function openEditModal(r, c) {
    editingPos = { r, c };
    const btn = rows[r][c];
    document.getElementById('editBtnLabel').value = btn.custom_label || '';
    document.getElementById('editBtnStyle').value = btn.style || '';
    document.getElementById('editBtnDisabled').checked = !!btn.disabled;
    document.getElementById('editModal').style.display = 'flex';
}
function closeEditModal() {
    document.getElementById('editModal').style.display = 'none';
}
document.getElementById('btnApplyEdit').addEventListener('click', () => {
    if (!editingPos) return;
    const btn = rows[editingPos.r][editingPos.c];
    const lbl = document.getElementById('editBtnLabel').value.trim();
    const stl = document.getElementById('editBtnStyle').value;
    const dis = document.getElementById('editBtnDisabled').checked;
    if (lbl) btn.custom_label = lbl; else delete btn.custom_label;
    if (stl) btn.style = stl; else delete btn.style;
    if (dis) btn.disabled = true; else delete btn.disabled;
    closeEditModal();
    renderAll();
});

document.getElementById('btnAddRow').addEventListener('click', () => {
    rows.push([{ text: 'text_support' }]);
    renderAll();
});

document.getElementById('btnAddButton').addEventListener('click', () => {
    const list = document.getElementById('catalogList');
    list.innerHTML = '';
    ACTION_CATALOG.forEach(item => {
        const el = document.createElement('button');
        el.type = 'button';
        el.className = 'uim-theme-btn';
        el.innerHTML = `<span>${escapeHtml(item.defaultLabel)}</span><small style="color:var(--mute)">${escapeHtml(item.desc)}</small>`;
        el.addEventListener('click', () => {
            rows[rows.length - 1].push({ text: item.key });
            document.getElementById('addModal').style.display = 'none';
            renderAll();
        });
        list.appendChild(el);
    });
    document.getElementById('addModal').style.display = 'flex';
});

document.getElementById('btnRevert').addEventListener('click', () => {
    rows = JSON.parse(JSON.stringify(INITIAL_KEYBOARD));
    renderAll();
});

document.querySelectorAll('.uim-theme-btn[data-theme]').forEach(btn => {
    btn.addEventListener('click', () => {
        activeTheme = btn.dataset.theme;
        const themeMap = {
            blue_neon:      { text_sell: 'primary', text_extend: 'primary', accountwallet: 'primary' },
            purple_premium: { text_sell: 'primary', text_extend: 'danger', accountwallet: 'success' },
            emerald:        { text_sell: 'success', text_extend: 'success', accountwallet: 'success' },
            dark_glass:     { text_sell: 'success', text_extend: 'primary', accountwallet: 'success' },
            gold_luxury:    { text_sell: 'success', text_extend: 'danger', accountwallet: 'primary' },
            midnight:       {},
        };
        const map = themeMap[activeTheme] || {};
        rows.forEach(r => r.forEach(b => {
            if (map[b.text]) b.style = map[b.text];
            else delete b.style;
        }));
        renderAll();
    });
});

document.getElementById('btnSaveMain').addEventListener('click', async () => {
    const statusEl = document.getElementById('saveStatus');
    statusEl.textContent = 'در حال ذخیره...';
    const res = await fetch('keyboard.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'X-XSRF-TOKEN': CSRF_TOKEN },
        body: JSON.stringify({ keyboard: rows })
    });
    const data = await res.json();
    statusEl.textContent = data.ok ? '✅ با موفقیت ذخیره شد و در ربات اعمال گردید.' : '❌ خطا در ذخیره‌سازی';
});

document.getElementById('btnSaveSub').addEventListener('click', async () => {
    const statusEl = document.getElementById('subSaveStatus');
    statusEl.textContent = 'در حال ذخیره...';
    const payload = {
        ui_config: {
            theme: activeTheme,
            product_columns: parseInt(document.getElementById('cfgProductCols').value, 10),
            category_columns: parseInt(document.getElementById('cfgCategoryCols').value, 10),
            duration_columns: parseInt(document.getElementById('cfgDurationCols').value, 10),
            product_price_separator: document.getElementById('cfgPriceSep').value,
            show_product_emoji: document.getElementById('cfgProductEmoji').checked,
        }
    };
    const res = await fetch('keyboard.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'X-XSRF-TOKEN': CSRF_TOKEN },
        body: JSON.stringify(payload)
    });
    const data = await res.json();
    statusEl.textContent = data.ok ? '✅ تنظیمات صفحات ذخیره شد.' : '❌ خطا در ذخیره';
});

document.querySelectorAll('.uim-tab[data-tab]').forEach(tab => {
    tab.addEventListener('click', () => {
        document.querySelectorAll('.uim-tab[data-tab]').forEach(t => t.classList.remove('active'));
        tab.classList.add('active');
        document.getElementById('tab-main').style.display = tab.dataset.tab === 'main' ? 'grid' : 'none';
        document.getElementById('tab-submenus').style.display = tab.dataset.tab === 'submenus' ? 'grid' : 'none';
    });
});

['cfgProductCols', 'cfgPriceSep', 'cfgProductEmoji'].forEach(id => {
    document.getElementById(id).addEventListener('input', renderProductPreview);
    document.getElementById(id).addEventListener('change', renderProductPreview);
});

function escapeHtml(str) {
    return String(str).replace(/[&<>"']/g, s => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[s]));
}

renderAll();
renderProductPreview();
</script>

<?php include __DIR__ . '/inc/layout_foot.php'; ?>
