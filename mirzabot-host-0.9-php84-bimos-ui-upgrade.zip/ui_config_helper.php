<?php

function mirza_ui_config_path(): string
{
    return __DIR__ . '/storage/ui_config.json';
}

function mirza_ui_default_config(): array
{
    return [
        'theme' => 'dark_glass',
        'product_columns' => 1,
        'category_columns' => 2,
        'duration_columns' => 2,
        'product_price_separator' => ' 💳 ',
        'show_product_emoji' => true,
    ];
}

function mirza_ui_get_config(): array
{
    $defaults = mirza_ui_default_config();
    $path = mirza_ui_config_path();
    if (!is_file($path)) {
        return $defaults;
    }
    $raw = @file_get_contents($path);
    if (!is_string($raw) || $raw === '') {
        return $defaults;
    }
    $decoded = json_decode($raw, true);
    if (!is_array($decoded)) {
        return $defaults;
    }
    return array_merge($defaults, $decoded);
}

function mirza_ui_save_config(array $config): bool
{
    $defaults = mirza_ui_default_config();
    $clean = [
        'theme' => in_array($config['theme'] ?? '', ['blue_neon', 'purple_premium', 'emerald', 'dark_glass', 'gold_luxury', 'midnight'], true)
            ? $config['theme'] : $defaults['theme'],
        'product_columns' => in_array((int) ($config['product_columns'] ?? 1), [1, 2], true)
            ? (int) $config['product_columns'] : 1,
        'category_columns' => in_array((int) ($config['category_columns'] ?? 2), [1, 2], true)
            ? (int) $config['category_columns'] : 2,
        'duration_columns' => in_array((int) ($config['duration_columns'] ?? 2), [1, 2], true)
            ? (int) $config['duration_columns'] : 2,
        'product_price_separator' => is_string($config['product_price_separator'] ?? null)
            ? mb_substr($config['product_price_separator'], 0, 12, 'UTF-8') : $defaults['product_price_separator'],
        'show_product_emoji' => !empty($config['show_product_emoji']),
    ];
    $path = mirza_ui_config_path();
    $dir = dirname($path);
    if (!is_dir($dir)) {
        @mkdir($dir, 0755, true);
    }
    return @file_put_contents($path, json_encode($clean, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT), LOCK_EX) !== false;
}
