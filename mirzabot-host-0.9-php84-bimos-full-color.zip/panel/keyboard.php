<?php
require_once __DIR__ . '/inc/config.php';
require_once __DIR__ . '/inc/icons.php';
require_auth();
setcookie('XSRF-TOKEN', csrf_token(), [
    'path' => '/',
    'secure' => !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off',
    'samesite' => 'Strict',
]);

$keyboard = json_decode(file_get_contents("php://input"), true);
$method = $_SERVER['REQUEST_METHOD'];
if ($method == "POST" && !csrf_check_value($_SERVER['HTTP_X_XSRF_TOKEN'] ?? '')) {
    http_response_code(403);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['ok' => false]);
    exit;
}
if ($method == "POST" && is_array($keyboard)) {
    $validKeyboard = count($keyboard) > 0;
    foreach ($keyboard as $row) {
        if (!is_array($row) || count($row) === 0) {
            $validKeyboard = false;
            break;
        }
        foreach ($row as $button) {
            if (!is_array($button) || !isset($button['text']) || !is_string($button['text']) || trim($button['text']) === '') {
                $validKeyboard = false;
                break 2;
            }
        }
    }
    header('Content-Type: application/json; charset=utf-8');
    if (!$validKeyboard) {
        http_response_code(422);
        echo json_encode(['ok' => false]);
        exit;
    }
    $keyboardmain = ['keyboard' => $keyboard];
    update("setting", "keyboardmain", json_encode($keyboardmain), null, null);
    echo json_encode(['ok' => true]);
    exit;
} else {
    $keyboardmain = '{"keyboard":[[{"text":"text_sell"},{"text":"text_extend"}],[{"text":"text_usertest"},{"text":"text_wheel_luck"}],[{"text":"text_Purchased_services"},{"text":"accountwallet"}],[{"text":"text_affiliates"},{"text":"text_Tariff_list"}],[{"text":"text_support"},{"text":"text_help"}],[{"text":"text_agentpanel"},{"text":"text_requestagent"}]]}';
    $action = filter_input(INPUT_GET, 'action');
    if ($action === "kbcolor") {
        csrf_check_get();
        $kbColor = (string) filter_input(INPUT_GET, 'color');
        $kbAllowedColors = ['primary', 'success', 'danger', 'default'];
        if (in_array($kbColor, $kbAllowedColors, true)) {
            $kbSetting = select("setting", "keyboardmain", null, null, "select");
            $kbLayout = json_decode($kbSetting['keyboardmain'] ?? '', true);
            if (is_array($kbLayout) && isset($kbLayout['keyboard']) && is_array($kbLayout['keyboard'])) {
                foreach ($kbLayout['keyboard'] as $kbRowIndex => $kbRow) {
                    if (!is_array($kbRow)) {
                        continue;
                    }
                    foreach ($kbRow as $kbBtnIndex => $kbBtn) {
                        if (!is_array($kbBtn)) {
                            continue;
                        }
                        if ($kbColor === 'default') {
                            unset($kbLayout['keyboard'][$kbRowIndex][$kbBtnIndex]['style']);
                        } else {
                            $kbLayout['keyboard'][$kbRowIndex][$kbBtnIndex]['style'] = $kbColor;
                        }
                    }
                }
                update("setting", "keyboardmain", json_encode($kbLayout, JSON_UNESCAPED_UNICODE), null, null);
            }
        }
        header('Location: keyboard.php');
        exit;
    }
    if ($action === "reaset") {
        csrf_check_get();
        update("setting", "keyboardmain", $keyboardmain, null, null);
        header('Location: keyboard.php');
        exit;
    }
}
?>

<!doctype html>
<html lang="FA">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title><?= $textbotlang['panel']['keyboardManageTitle'] ?></title>

    <script type="module" crossorigin src="js/sort_keyboard.js"></script>
    <link rel="stylesheet" crossorigin href="css/sort_keyboard.css">
    <style>
        @import url(https://fonts.googleapis.com/css2?family=Vazirmatn:wght@300;400;500;600;700;800&family=JetBrains+Mono:wght@400;500&display=swap);

        * {
            font-family: 'Vazirmatn' !important;
        }

        button {
            font-family: yekan;
        }

        .btnback {
            position: fixed;
            top: 10px;
            left: 10px;
            padding: 7px;
            background-color: #3d3d3d;
            color: #fff;
            border-radius: 6px;
            font-family: yekan;
            font-size: 13px;
            font-weight: bold;
        }

        .btndefult {
            position: fixed;
            top: 10px;
            left: 150px;
            padding: 7px;
            background-color: #fff;
            border: 2px solid #3d3d3d;
            color: #3d3d3d;
            border-radius: 6px;
            font-family: yekan;
            font-size: 13px;
            font-weight: bold;
        }

        .kbcolorbar {
            margin: 54px 10px 0;
            display: flex;
            flex-wrap: wrap;
            align-items: center;
            gap: 8px;
            direction: rtl;
            font-size: 13px;
            font-weight: bold;
            color: #111827;
        }

        .kbcolorbtn {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            padding: 7px 10px;
            border-radius: 999px;
            border: 1px solid #d1d5db;
            background-color: #fff;
            color: #111827;
            text-decoration: none;
        }

        .kbcolor-dot {
            width: 12px;
            height: 12px;
            border-radius: 999px;
            display: inline-block;
            border: 1px solid rgba(0, 0, 0, .15);
        }

        .kbcolornote {
            font-weight: normal;
            color: #6b7280;
        }
    </style>
</head>

<body>
    <a class="btnback" href="index.php"><?= $textbotlang['panel']['keyboardSortHint'] ?></a>
    <a class="btndefult" href="keyboard.php?action=reaset&_csrf=<?= urlencode(csrf_token()) ?>"><?= $textbotlang['panel']['keyboardSaveBtn'] ?></a>
    <div class="kbcolorbar">
        <span>رنگ همهٔ دکمه‌های کیبورد اصلی:</span>
        <a class="kbcolorbtn" href="keyboard.php?action=kbcolor&color=primary&_csrf=<?= urlencode(csrf_token()) ?>" onclick="return confirm('اگر در چیدمان تغییر ذخیره‌نشده دارید، اول آن را ذخیره کنید. رنگ روی چیدمان ذخیره‌شده اعمال شود؟')"><span class="kbcolor-dot" style="background-color:#298acf"></span>آبی</a>
        <a class="kbcolorbtn" href="keyboard.php?action=kbcolor&color=success&_csrf=<?= urlencode(csrf_token()) ?>" onclick="return confirm('اگر در چیدمان تغییر ذخیره‌نشده دارید، اول آن را ذخیره کنید. رنگ روی چیدمان ذخیره‌شده اعمال شود؟')"><span class="kbcolor-dot" style="background-color:#61c752"></span>سبز</a>
        <a class="kbcolorbtn" href="keyboard.php?action=kbcolor&color=danger&_csrf=<?= urlencode(csrf_token()) ?>" onclick="return confirm('اگر در چیدمان تغییر ذخیره‌نشده دارید، اول آن را ذخیره کنید. رنگ روی چیدمان ذخیره‌شده اعمال شود؟')"><span class="kbcolor-dot" style="background-color:#e05356"></span>قرمز</a>
        <a class="kbcolorbtn" href="keyboard.php?action=kbcolor&color=default&_csrf=<?= urlencode(csrf_token()) ?>" onclick="return confirm('اگر در چیدمان تغییر ذخیره‌نشده دارید، اول آن را ذخیره کنید. رنگ همهٔ دکمه‌ها به سفید/پیش‌فرض برگردد؟')"><span class="kbcolor-dot" style="background-color:#ffffff"></span>سفید/پیش‌فرض</a>
        <span class="kbcolornote">(روی چیدمان ذخیره‌شده اعمال می‌شود)</span>
    </div>
    <div id="root"></div>
</body>

</html>